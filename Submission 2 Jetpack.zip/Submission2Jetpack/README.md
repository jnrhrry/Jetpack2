# MovieCatalogue
This app intended to complete second submission at Dicoding for Belajar Android Jetpack Pro course.

Here is the glimps of the app:

![movie2](https://user-images.githubusercontent.com/55497456/95009876-644ec900-064f-11eb-8740-de0a62864405.gif)
