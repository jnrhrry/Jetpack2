package com.januar.submission2jetpack.utils

interface Listeners{
    fun onStarted()
    fun onFinished()
    fun onError(message: String)
}