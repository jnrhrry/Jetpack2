package com.januar.submission2jetpack.utils.test

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}