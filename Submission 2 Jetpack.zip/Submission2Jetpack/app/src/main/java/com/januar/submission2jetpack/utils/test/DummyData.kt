package com.januar.submission2jetpack.utils.test

import com.januar.submission2jetpack.data.remote.response.movie.MovieDetailsResponse
import com.januar.submission2jetpack.data.remote.response.movie.MovieResponse
import com.januar.submission2jetpack.data.remote.response.movie.MovieResult
import com.januar.submission2jetpack.data.remote.response.tvseries.SeriesDetailsResponse
import com.januar.submission2jetpack.data.remote.response.tvseries.SeriesResult

object DummyData {
    fun getDummyMovie(): List<MovieResult> {
        val movie = ArrayList<MovieResult>()

        movie.add(MovieResult(
            "In Scooby-Doo’s greatest adventure yet, see the never-before told story of how lifelong friends Scooby and Shaggy first met and how they joined forces with young detectives Fred, Velma, and Daphne to form the famous Mystery Inc. Now, with hundreds of cases solved, Scooby and the gang face their biggest, toughest mystery ever: an evil plot to unleash the ghost dog Cerberus upon the world. As they race to stop this global “dogpocalypse,” the gang discovers that Scooby has a secret legacy and an epic destiny greater than anyone ever imagined.",
            "07/08/2020",
            385103,
            "Scoob!",
            "/fKtYXUhX5fxMxzQfyUcQW9Shik6.jpg",
            7.4
        ))
        movie.add(MovieResult(
            "A first-time captain leads a convoy of allied ships carrying thousands of soldiers across the treacherous waters of the “Black Pit” to the front lines of WW2. With no air cover protection for 5 days, the captain and his convoy must battle the surrounding enemy Nazi U-boats in order to give the allies a chance to win the war.",
            "07/10/2020",
            516486,
            "Greyhound",
            "/kjMbDciooTbJPofVXgAoFjfX8Of.jpg",
            7.5
        ))
        movie.add(MovieResult(
            "With college decisions looming, Elle juggles her long-distance romance with Noah, changing relationship with bestie Lee and feelings for a new classmate.",
            "07/24/2020",
            583083,
            "The Kissing Booth 2",
            "/wO5QSWZPBT71gMLvrRex0bVc0V9.jpg",
            8.2
            ))
        movie.add(MovieResult(
            "Four undying warriors who've secretly protected humanity for centuries become targeted for their mysterious powers just as they discover a new immortal.",
            "07/10/2020",
            547016,
            "The Old Guard",
            "/m0ObOaJBerZ3Unc74l471ar8Iiy.jpg",
            7.4
        ))

        movie.add(MovieResult(
            "In Scooby-Doo’s greatest adventure yet, see the never-before told story of how lifelong friends Scooby and Shaggy first met and how they joined forces with young detectives Fred, Velma, and Daphne to form the famous Mystery Inc. Now, with hundreds of cases solved, Scooby and the gang face their biggest, toughest mystery ever: an evil plot to unleash the ghost dog Cerberus upon the world. As they race to stop this global “dogpocalypse,” the gang discovers that Scooby has a secret legacy and an epic destiny greater than anyone ever imagined.",
            "07/08/2020",
            385103,
            "Scoob!",
            "/fKtYXUhX5fxMxzQfyUcQW9Shik6.jpg",
            7.4
        ))
        movie.add(MovieResult(
            "A first-time captain leads a convoy of allied ships carrying thousands of soldiers across the treacherous waters of the “Black Pit” to the front lines of WW2. With no air cover protection for 5 days, the captain and his convoy must battle the surrounding enemy Nazi U-boats in order to give the allies a chance to win the war.",
            "07/10/2020",
            516486,
            "Greyhound",
            "/kjMbDciooTbJPofVXgAoFjfX8Of.jpg",
            7.5
        ))
        movie.add(MovieResult(
            "With college decisions looming, Elle juggles her long-distance romance with Noah, changing relationship with bestie Lee and feelings for a new classmate.",
            "07/24/2020",
            583083,
            "The Kissing Booth 2",
            "/wO5QSWZPBT71gMLvrRex0bVc0V9.jpg",
            8.2
        ))
        movie.add(MovieResult(
            "Four undying warriors who've secretly protected humanity for centuries become targeted for their mysterious powers just as they discover a new immortal.",
            "07/10/2020",
            547016,
            "The Old Guard",
            "/m0ObOaJBerZ3Unc74l471ar8Iiy.jpg",
            7.4
        ))
        movie.add(MovieResult(
            "In Scooby-Doo’s greatest adventure yet, see the never-before told story of how lifelong friends Scooby and Shaggy first met and how they joined forces with young detectives Fred, Velma, and Daphne to form the famous Mystery Inc. Now, with hundreds of cases solved, Scooby and the gang face their biggest, toughest mystery ever: an evil plot to unleash the ghost dog Cerberus upon the world. As they race to stop this global “dogpocalypse,” the gang discovers that Scooby has a secret legacy and an epic destiny greater than anyone ever imagined.",
            "07/08/2020",
            385103,
            "Scoob!",
            "/fKtYXUhX5fxMxzQfyUcQW9Shik6.jpg",
            7.4
        ))
        movie.add(MovieResult(
            "A first-time captain leads a convoy of allied ships carrying thousands of soldiers across the treacherous waters of the “Black Pit” to the front lines of WW2. With no air cover protection for 5 days, the captain and his convoy must battle the surrounding enemy Nazi U-boats in order to give the allies a chance to win the war.",
            "07/10/2020",
            516486,
            "Greyhound",
            "/kjMbDciooTbJPofVXgAoFjfX8Of.jpg",
            7.5
        ))
        movie.add(MovieResult(
            "With college decisions looming, Elle juggles her long-distance romance with Noah, changing relationship with bestie Lee and feelings for a new classmate.",
            "07/24/2020",
            583083,
            "The Kissing Booth 2",
            "/wO5QSWZPBT71gMLvrRex0bVc0V9.jpg",
            8.2
        ))
        movie.add(MovieResult(
            "Four undying warriors who've secretly protected humanity for centuries become targeted for their mysterious powers just as they discover a new immortal.",
            "07/10/2020",
            547016,
            "The Old Guard",
            "/m0ObOaJBerZ3Unc74l471ar8Iiy.jpg",
            7.4
        ))
        return movie
    }

    fun getDummySeries(): List<SeriesResult>{
        val series = ArrayList<SeriesResult>()
        series.add(SeriesResult(
            "1997-04-01",
            60572,
            "Pokémon",
            "Join Satoshi, accompanied by his partner Pikachu, as he travels through many regions, meets new friends and faces new challenges on his quest to become a Pokémon Master.",
            "/rOuGm07PxBhEsK9TaGPRQVJQm1X.jpg",
            6.7,
            100
        ))
        series.add(SeriesResult(
                "2018-01-22",
                10160,
                "The Alienist",
                "New York, 1896. Police commissioner Theodore Roosevelt brings together criminal psychologist Dr. Laszlo Kreizler, newspaper illustrator John Moore and secretary Sara Howard to investigate several murders of male prostitutes.",
                "/1qzuS7b2XjiVcWwmDkOyE5hIxUM.jpg",
                7.6,
                100
        ))
        series.add(SeriesResult(
                "2019-02-15",
                75006,
                "The Umbrella Academy",
                "A dysfunctional family of superheroes comes together to solve the mystery of their father's death, the threat of the apocalypse and more.",
                "/scZlQQYnDVlnpxFTxaIv2g0BWnL.jpg",
                8.4,
                100
            ))

        series.add(SeriesResult(
            "1997-04-01",
            60572,
            "Pokémon",
            "Join Satoshi, accompanied by his partner Pikachu, as he travels through many regions, meets new friends and faces new challenges on his quest to become a Pokémon Master.",
            "/rOuGm07PxBhEsK9TaGPRQVJQm1X.jpg",
            6.7,
            100
        ))
        series.add(SeriesResult(
            "2018-01-22",
            10160,
            "The Alienist",
            "New York, 1896. Police commissioner Theodore Roosevelt brings together criminal psychologist Dr. Laszlo Kreizler, newspaper illustrator John Moore and secretary Sara Howard to investigate several murders of male prostitutes.",
            "/1qzuS7b2XjiVcWwmDkOyE5hIxUM.jpg",
            7.6,
            100
        ))
        series.add(SeriesResult(
            "2019-02-15",
            75006,
            "The Umbrella Academy",
            "A dysfunctional family of superheroes comes together to solve the mystery of their father's death, the threat of the apocalypse and more.",
            "/scZlQQYnDVlnpxFTxaIv2g0BWnL.jpg",
            8.4,
            100
        ))
        series.add(SeriesResult(
            "1997-04-01",
            60572,
            "Pokémon",
            "Join Satoshi, accompanied by his partner Pikachu, as he travels through many regions, meets new friends and faces new challenges on his quest to become a Pokémon Master.",
            "/rOuGm07PxBhEsK9TaGPRQVJQm1X.jpg",
            6.7,
            100
        ))
        series.add(SeriesResult(
            "2018-01-22",
            10160,
            "The Alienist",
            "New York, 1896. Police commissioner Theodore Roosevelt brings together criminal psychologist Dr. Laszlo Kreizler, newspaper illustrator John Moore and secretary Sara Howard to investigate several murders of male prostitutes.",
            "/1qzuS7b2XjiVcWwmDkOyE5hIxUM.jpg",
            7.6,
            100
        ))
        series.add(SeriesResult(
            "2019-02-15",
            75006,
            "The Umbrella Academy",
            "A dysfunctional family of superheroes comes together to solve the mystery of their father's death, the threat of the apocalypse and more.",
            "/scZlQQYnDVlnpxFTxaIv2g0BWnL.jpg",
            8.4,
            100
        ))
        series.add(SeriesResult(
            "1997-04-01",
            60572,
            "Pokémon",
            "Join Satoshi, accompanied by his partner Pikachu, as he travels through many regions, meets new friends and faces new challenges on his quest to become a Pokémon Master.",
            "/rOuGm07PxBhEsK9TaGPRQVJQm1X.jpg",
            6.7,
            100
        ))
        series.add(SeriesResult(
            "2018-01-22",
            10160,
            "The Alienist",
            "New York, 1896. Police commissioner Theodore Roosevelt brings together criminal psychologist Dr. Laszlo Kreizler, newspaper illustrator John Moore and secretary Sara Howard to investigate several murders of male prostitutes.",
            "/1qzuS7b2XjiVcWwmDkOyE5hIxUM.jpg",
            7.6,
            100
        ))
        series.add(SeriesResult(
            "2019-02-15",
            75006,
            "The Umbrella Academy",
            "A dysfunctional family of superheroes comes together to solve the mystery of their father's death, the threat of the apocalypse and more.",
            "/scZlQQYnDVlnpxFTxaIv2g0BWnL.jpg",
            8.4,
            100
        ))
        return series
    }

    fun getDummyMovieDetail(): MovieDetailsResponse {
        return MovieDetailsResponse(
            "Scoob!",
            "In Scooby-Doo’s greatest adventure yet, see the never-before told story of how lifelong friends Scooby and Shaggy first met and how they joined forces with young detectives Fred, Velma, and Daphne to form the famous Mystery Inc. Now, with hundreds of cases solved, Scooby and the gang face their biggest, toughest mystery ever: an evil plot to unleash the ghost dog Cerberus upon the world. As they race to stop this global “dogpocalypse,” the gang discovers that Scooby has a secret legacy and an epic destiny greater than anyone ever imagined.",
            "/fKtYXUhX5fxMxzQfyUcQW9Shik6.jpg",
            "07/08/2020",
            false,
            8.4,
            100

        )
    }

    fun getDummySeriesDetails(): SeriesDetailsResponse{
        return SeriesDetailsResponse(
            "2019-02-15",
            75006,
            "The Umbrella Academy",
            "A dysfunctional family of superheroes comes together to solve the mystery of their father's death, the threat of the apocalypse and more.",
            8.4,
            "/scZlQQYnDVlnpxFTxaIv2g0BWnL.jpg",
            8.4
        )
    }
}