package com.januar.submission2jetpack.detail

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.januar.submission2jetpack.data.remote.response.movie.MovieDetailsResponse
import com.januar.submission2jetpack.data.remote.response.tvseries.SeriesDetailsResponse
import com.januar.submission2jetpack.repository.Repository
import com.januar.submission2jetpack.ui.details.DetailsViewModel
import com.januar.submission2jetpack.utils.test.DummyData
import junit.framework.Assert.assertEquals
import junit.framework.Assert.assertNotNull
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito.`when`
import org.mockito.Mockito.verify
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class DetailViewModelTest {
    private lateinit var viewModel: DetailsViewModel

    private val dummyMovie = DummyData.getDummyMovieDetail()
    private val dummySeries = DummyData.getDummySeriesDetails()

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    @Mock
    private lateinit var repository: Repository

    @Mock
    private lateinit var movieObserver: Observer<MovieDetailsResponse>

    @Mock
    private lateinit var seriesObserver: Observer<SeriesDetailsResponse>

    @Test
    suspend fun getDetailMovie(){
        val id = 1
        val movie = MutableLiveData<MovieDetailsResponse>()
        movie.value = dummyMovie

        `when`(repository.getMovieDetails(id)).thenReturn(dummyMovie)
        val movieDetail = viewModel.getMovieDetails(id).value
        verify(repository).getMovieDetails(id)

        assertNotNull(movieDetail)
        assertEquals(movieDetail?.originalTitle, dummyMovie.originalTitle)
        assertEquals(movieDetail?.posterPath, dummyMovie.posterPath)
        assertEquals(movieDetail?.voteAverage, dummyMovie.voteAverage)
        assertEquals(movieDetail?.overview, dummyMovie.overview)
        assertEquals(movieDetail?.releaseDate, dummyMovie.releaseDate)

        viewModel.getMovieDetails(id).observeForever(movieObserver)
        verify(movieObserver).onChanged(dummyMovie)
    }

    @Test
    suspend fun getDetailSeries(){
        val idS = dummySeries.id
        val series = MutableLiveData<SeriesDetailsResponse>()
        series.value = dummySeries

        `when`(repository.getSeriesDetails(idS)).thenReturn(dummySeries)
        val seriesDetail = viewModel.getSeriesDetails(idS).value
        verify(repository).getSeriesDetails(idS)

        assertNotNull(seriesDetail)
        assertEquals(seriesDetail?.id, idS)
        assertEquals(seriesDetail?.originalName, dummySeries.originalName)
        assertEquals(seriesDetail?.posterPath, dummySeries.posterPath)
        assertEquals(seriesDetail?.voteAverage, dummySeries.voteAverage)
        assertEquals(seriesDetail?.overview, dummySeries.overview)
        assertEquals(seriesDetail?.firstAirDate, dummySeries.firstAirDate)

        viewModel.getSeriesDetails(idS).observeForever(seriesObserver)
        verify(seriesObserver).onChanged(dummySeries)
    }
}