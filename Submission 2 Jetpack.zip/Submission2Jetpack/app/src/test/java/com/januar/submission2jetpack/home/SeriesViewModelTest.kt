package com.januar.submission2jetpack.home

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.januar.submission2jetpack.data.remote.response.tvseries.SeriesResponse
import com.januar.submission2jetpack.data.remote.response.tvseries.SeriesResult
import com.januar.submission2jetpack.repository.Repository
import com.januar.submission2jetpack.ui.main.tvseries.TVSeriesViewModel
import com.januar.submission2jetpack.utils.test.DummyData
import junit.framework.Assert.assertEquals
import junit.framework.Assert.assertNotNull
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito.`when`
import org.mockito.Mockito.verify
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class SeriesViewModelTest {

    private lateinit var viewModel: TVSeriesViewModel

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    @Mock
    private lateinit var repository: Repository

    @Mock
    private lateinit var observer: Observer<List<SeriesResult>>

    @Before
    fun setUp(){
        viewModel = TVSeriesViewModel(repository)
    }

    @Test
    suspend fun getSeries(){
        val seriesList = MutableLiveData<List<SeriesResult>>()
        val dummy = DummyData.getDummySeries()
        seriesList.value = dummy

        `when`(repository.getTVSeries()).thenReturn(SeriesResponse(dummy))
        viewModel.getAllSeries()
        val data = viewModel.seriesLive
        verify(repository).getTVSeries()

        assertNotNull(data)
        assertEquals(13, data.value?.size)

        viewModel.seriesLive.observeForever(observer)
        verify(observer).onChanged(dummy)
    }
}