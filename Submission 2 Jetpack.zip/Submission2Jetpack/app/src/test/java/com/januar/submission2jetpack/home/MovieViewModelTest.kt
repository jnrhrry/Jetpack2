package com.januar.submission2jetpack.home

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.januar.submission2jetpack.data.remote.response.movie.MovieResponse
import com.januar.submission2jetpack.data.remote.response.movie.MovieResult
import com.januar.submission2jetpack.repository.Repository
import com.januar.submission2jetpack.ui.main.movie.MoviesViewModel
import com.januar.submission2jetpack.utils.test.DummyData
import com.nhaarman.mockitokotlin2.verify
import junit.framework.Assert.assertEquals
import junit.framework.Assert.assertNotNull
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito.`when`
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class MovieViewModelTest {
    private lateinit var viewModel: MoviesViewModel

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    @Mock
    private lateinit var repository: Repository

    @Mock
    private lateinit var observer: Observer<List<MovieResult>>

    @Before
    fun setUp(){
        viewModel = MoviesViewModel(repository)
    }

    @Test
    suspend fun getMovie(){
        val movieList = MutableLiveData<List<MovieResult>>()
        val dummy = DummyData.getDummyMovie()
        movieList.value = dummy

        `when`(repository.getMovies()).thenReturn(MovieResponse(dummy))
        viewModel.getAllMovies()
        val movie = viewModel.moviesLive
        verify(repository).getMovies()

        assertNotNull(movie)
        assertEquals(13, movie.value?.size)

        viewModel.moviesLive.observeForever(observer)
        verify(observer).onChanged(dummy)
    }

}