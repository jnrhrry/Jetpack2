package com.januar.submission2jetpack.ui

import androidx.recyclerview.widget.RecyclerView
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.IdlingPolicies
import androidx.test.espresso.IdlingRegistry
import androidx.test.espresso.action.ViewActions
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.contrib.RecyclerViewActions
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.rule.ActivityTestRule
import com.januar.submission2jetpack.R
import com.januar.submission2jetpack.ui.main.home.HomeActivity
import com.januar.submission2jetpack.utils.test.DummyData
import com.januar.submission2jetpack.utils.test.EspressoIdlingResource
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test

class HomeActivityTest {

    private val dummyMovie = DummyData.getDummyMovie()
    private val dummySeries = DummyData.getDummySeries()
    @get:Rule
    var activityRule = ActivityTestRule(HomeActivity::class.java)

    @Before
    fun setUp(){
        IdlingRegistry.getInstance().register(EspressoIdlingResource.idlingResource)
        IdlingPolicies.setMasterPolicyTimeout(3, java.util.concurrent.TimeUnit.MINUTES);
        IdlingPolicies.setIdlingResourceTimeout(3, java.util.concurrent.TimeUnit.MINUTES);
    }

    @After
    fun tearDown(){
        IdlingRegistry.getInstance().unregister(EspressoIdlingResource.idlingResource)
    }

    @Test
    fun getMovie(){
        onView(withId(R.id.movie_rv))
            .check(matches(isDisplayed()))
        onView(withId(R.id.movie_rv))
            .perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(dummyMovie.size))
    }

    @Test
    fun getMovieDetails(){
        onView(withId(R.id.movie_rv)).perform(
            RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(0,
                ViewActions.click()
            ))
        onView(withId(R.id.toolbar)).perform(ViewActions.click())
        onView(withId(R.id.movie_detail_poster)).check(matches(isDisplayed()))
        onView(withId(R.id.movie_rating)).check(matches(isDisplayed()))
        onView(withId(R.id.release_date)).check(matches(isDisplayed()))
        onView(withId(R.id.movie_overview)).check(matches(isDisplayed()))
    }

    @Test
    fun getTVSeries(){
        onView(withText("TV Series")).perform(ViewActions.click())
        onView(withId(R.id.series_rv))
            .check(matches(isDisplayed()))
        onView(withId(R.id.series_rv))
            .perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(dummySeries.size))
    }

    @Test
    fun getTVSeriesDetails(){
        onView(withText("TV Series")).perform(ViewActions.click())
        onView(withId(R.id.series_rv)).perform(
            RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(0,
                ViewActions.click()
            ))
        onView(withId(R.id.toolbar)).perform(ViewActions.click())
        onView(withId(R.id.movie_detail_poster)).check(matches(isDisplayed()))
        onView(withId(R.id.movie_rating)).check(matches(isDisplayed()))
        onView(withId(R.id.release_date)).check(matches(isDisplayed()))
        onView(withId(R.id.movie_overview)).check(matches(isDisplayed()))
    }
}